# Handoff: Axiom Aerial — Deep-Tech UAV & Edge AI Platform

## Overview
Marketing + recruiting site for **Axiom Aerial**, a deep-tech startup that builds UAV platforms, embedded systems, edge AI and computer vision — and runs hands-on engineering internships. This bundle covers two screens:

1. **Landing page** (`index.html`) — cinematic 3D hero, capabilities, interactive 3D drone "exploder", metrics, R&D showcase, CTA, footer.
2. **Internship portal** (`internships.html`) — hero, 5 tracks, weekly roadmap, 3-step application form with success state.

The original product spec targets **Next.js 14 (App Router) + TypeScript + Tailwind + React Three Fiber/Drei + Framer Motion + Zod + Prisma/PostgreSQL**. Recommended mapping is given below.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, **not production code to copy directly**. The task is to **recreate these designs in the target codebase's environment** (recommended: Next.js + Tailwind + R3F) using its established patterns. The procedural Three.js drone is a stand-in for the production GLTF models (`drone_hero.glb`, `drone_detailed.glb`).

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy and interactions. Recreate pixel-accurately. Only the 3D geometry (procedural primitives) and SVG project visuals are placeholders for real assets.

---

## Design Tokens

### Colors
| Token | Hex | Use |
|---|---|---|
| `g-950` | `#050709` | Page background |
| `g-925` | `#080b10` | Alternate section bg, footer, input bg |
| `g-900` | `#0b0f16` | Card background |
| `g-850` | `#10151e` | Card hover |
| `g-800` | `#161c27` | Elevated surface |
| `g-750` | `#1d2532` | — |
| `g-700` | `#252e3d` | Borders, dividers, 1px grid gaps |
| `g-600` | `#3a4557` | Dashed borders, muted icons |
| `g-500` | `#5b6678` | Mono labels, meta text |
| `g-400` | `#8892a3` | Body secondary |
| `g-300` | `#b8c0ce` | Body primary on dark |
| `g-200` | `#d8dde6` | Ghost button text |
| `g-100` | `#eef1f6` | Headings |
| `cyan` | `#3ee6ff` | Primary accent / interactive / glow |
| `cyan-dim` | `#1aa4bf` | Emissive on 3D accent material |
| `amber` | `#f5a524` | Status, secondary eyebrow, motor caps |
| `amber-dim` | `#a56e15` | Emissive amber |
| `green` | `#4ade80` | "Live" status dot |
| `red` | `#ef4a4a` | Reserved for errors |

Glows: `0 0 24px rgba(62,230,255,.35)` (primary btn), `0 0 8px <color>` (status dots), `0 0 40px rgba(62,230,255,.3)` (success check).

### Typography
Fonts (Google): **Space Grotesk** (400–700, display), **Inter** (300–700, body), **JetBrains Mono** (400–600, labels/specs).

| Role | Font | Size | Weight | Line-height | Tracking | Case |
|---|---|---|---|---|---|---|
| Hero H1 | Space Grotesk | `clamp(44px, 6.4vw, 92px)` | 600 | .98 | -.03em | UPPER |
| Internship H1 | Space Grotesk | `clamp(48px, 6vw, 88px)` | 600 | .98 | -.03em | UPPER |
| Section H2 | Space Grotesk | `clamp(32px, 3.6vw, 52px)` | 500 | 1.02 | -.02em | UPPER |
| Card title | Space Grotesk | 20–24px | 600 | — | .02em | UPPER |
| Stat value | Space Grotesk | `clamp(38px, 4vw, 56px)` | 600 | 1 | — | — |
| Eyebrow | JetBrains Mono | 11px | 500 | — | .32em | UPPER, cyan, preceded by 24×1px line |
| Mono label | JetBrains Mono | 10–11px | 400–500 | — | .14–.22em | UPPER |
| Button | JetBrains Mono | 12px | 500 | — | .18em | UPPER |
| Body | Inter | 14–16px (hero sub `clamp(15px,1.15vw,18px)`) | 400 | 1.6 | — | — |

### Spacing / Layout
- Container: `max-width: 1400px; padding: 0 32px` (20px ≤768px). Hero grid max 1500px.
- Section padding: `120px 0` (80px ≤768px).
- Section header: 2-col grid, gap 60px, `align-items:end`, margin-bottom 64px.
- Card grids use **1px gaps on a `g-700` background** to draw hairline dividers (signature pattern).
- Background grid overlay: 64px lines at `rgba(255,255,255,.025)`, radial mask.

### Radius & Borders
- Radius: **2px** on buttons/badges; **0** on cards/inputs (sharp, technical). Only circles are round.
- Borders: 1px `g-700`; hover → `cyan`. Dashed `g-700` for spec rows.
- **Corner ticks** (`.ticks`): 10×10px L-brackets in cyan, opacity .7, on each corner of form panel. Hero has 24px corner brackets at opacity .5.

---

## Screens

### 1. Landing (`index.html`)

**Navbar** — fixed, `padding:16px 32px`, gradient bg `rgba(5,7,9,.85)→transparent`, `backdrop-filter: blur(12px)`, bottom border `rgba(37,46,61,.5)`. Left: triangle logo SVG + "AXIOM AERIAL" (Space Grotesk 600 15px) + "AX-01" mono cyan tag. Center: links Systems / Technology / R&D / Internships / Contact (mono 12px, .12em, `g-400`, hover/active cyan). Right: green pulsing dot + "LABS OPERATIONAL". Links + status hide ≤900px (add mobile slide-over menu in production).

**Hero** — `min-height:100vh`, padding-top 100px. Full-bleed Three.js canvas behind; 2-col grid (1.05fr / .95fr, gap 60px); left column content, right reserved for drone (drone positioned `x:+0.7` in scene). Radial cyan glow at 70% 55%.
- Eyebrow: "AX-001 · Deep-Tech Systems Lab"
- H1: "Engineering the / future of / **autonomous flight.**" (last line cyan with 2px underline at 40% opacity)
- Sub: "Axiom Aerial builds practical UAV platforms, embedded AI stacks, and computer vision systems from first principles — and trains the next generation of engineers through project-first, hardware-real programs."
- CTAs: Primary "Explore the technology →" (cyan fill, `g-950` text) → `#build`; Ghost "Enter internship portal →" → internships.
- Meta row (3-col, top border): Inference Latency 11.8ms · Onboard Compute 40 TOPS · RTK Precision ±1.4cm.
- HUD panels (hidden ≤1024px): top-right "// Node AX-LAB.01 / BLR"; bottom-right "// Flight Stack PX4 · MAVLINK · ROS2".

**Ticker** — full-width band, 1px borders, mono 11px .2em; infinite translateX(-50%) scroll over 45s linear; content duplicated for seamless loop. Cyan bold keys, amber "◉ STATUS: OPERATIONAL".

**Trust strip** — `g-925` bg, 36px padding; 7 pillars "◆ UAV Systems / Embedded Systems / Edge AI / Computer Vision / Robotics / Wireless Comms / R&D Labs", separated by `/` in `g-700`. Hover → cyan.

**What We Build** (`#build`) — 3-col grid (2 ≤1024, 1 ≤640), 1px gaps. Card: `g-900`, padding 40/32/36, min-height 320px. Top row "// 0N — CAP" + "↗" (arrow moves +4,-4 and turns cyan on hover). 2px cyan left bar scales in from top on hover (.3s). Title, description, tech badges. Content in `build-cards.js` (6 cards: UAV Systems, Embedded Systems, Edge AI, Computer Vision, Robotics, R&D & Prototyping).

**Inside the System — Exploder** (`#exploder`) — 3-col grid `340px 1fr 340px`, min-height 720px (stacks ≤1100px).
- Left: list of 8 hotspot items (`// 0N / 08`, name, spec). Hover or click activates. Active: cyan border, `rgba(62,230,255,.06)` bg, 2px cyan left bar.
- Center: 3D canvas, radial bg `g-850→g-925`. HUD top-left "AX-1 REFERENCE PLATFORM" + active part name in cyan. Bottom-center control bar: **Explode** (default on), **Auto-Rotate**, **Reset**.
- Right: detail panel — eyebrow "§ AX-1 · Component 0N", title, description, 4 spec rows (dashed dividers, key `g-500`, value cyan), status "NOMINAL · FIELD-VALIDATED" with green dot.
- Hotspot data (id, name, spec, desc, 4 specs) is fully defined in `exploder.js` `HOTSPOTS`: Camera & Gimbal, Flight Controller, GPS/RTK, Motor & ESC, Smart Battery, Comms Link, Edge Compute, Sensor Suite.

**Metrics** — 4-col stat grid (2 ≤768): Airframes deployed 12 · Engineers trained 340+ · Flight hours 1,840 · R&D uptime 99.4%. Units in mono cyan 16px.

**R&D Showcase** (`#projects`) — 3 cards (1-col ≤1024), gap 24px. Card: 220px visual header (SVG on 20px grid pattern), body padding 24. Meta row: code (mono cyan) + status dot label. Hover → cyan border.
- AX-P01 AeroScan — Multispectral Crop Health — status "Field trial" (green). Visual: NDVI plots + lawnmower scan path + pulsing drone.
- AX-P02 EdgeTrack — Real-Time Onboard Tracking — "Beta" (amber). Visual: detection boxes w/ corner brackets + confidence labels + crosshair + HUD text.
- AX-P03 SwarmNode — Decentralized Multi-Drone Mesh — "Research" (cyan). Visual: 7-node mesh, amber lead node with pulse.
Replace SVGs with real imagery/video in production.

**CTA band** (`#contact`) — centered, radial cyan glow. Eyebrow amber "§ 06 · Join the lab", H2 "Build with us. / Learn by shipping.", body, buttons "Apply to internship →" / "Book a lab tour →".

**Footer** — 4-col grid `1.4fr 1fr 1fr 1fr` gap 60 (2-col ≤900, 1 ≤520). Brand + tagline + badges (Labs Live, DGCA · Type A). Columns Technology / Programs / Contact. Bottom bar: © line + build code "AX-WEB · v5.0.2 · BUILD 20260917".

### 2. Internship Portal (`internships.html`)
- **Nav**: same, Internships active; status "Cohort AX-25 · Open" with amber dot.
- **Hero**: centered, padding-top 160px, max 1000px. Eyebrow amber, H1 "Build. Test. / Learn. **Deploy.**" (Deploy cyan), subheading, stats row (Duration 4–8wk · Tracks 05 · Cohort Size 32 · Placement 94%).
- **Tracks**: stacked list, 1px dividers. Row grid `70px 1fr auto`, padding 36/40. Code (mono 28px cyan), name, info (Duration · Mode · Cohort), tags, "Apply →" button (turns cyan on row hover). Click → scroll to `#apply`. In production, link to `/internships/[slug]`.
  - 01 Drone & UAV Technology · Hybrid/Offline Labs · PX4, MAVLink, CAD, Flight Dynamics
  - 02 Embedded Systems & Firmware · Hybrid/Offline · C/C++, STM32, FreeRTOS, PCB Design
  - 03 AI & Computer Vision · Online/Hybrid · Python, OpenCV, PyTorch, YOLO
  - 04 Autonomous Robotics · Offline Labs · ROS2, Gazebo, LiDAR, Nav2
  - 05 Edge AI & Embedded ML · Hybrid · TensorRT, ONNX, Jetson, Quantization
- **Weekly Roadmap**: 4-col (2 ≤900, 1 ≤560) — Week 01 Foundations & Toolchain · 02 Hardware Integration · 03 Core Development · 04 Validation & Ship.
- **Application form** (`#apply`): panel `g-900`, 1px border, padding 48 (32/24 mobile), max-width 920, corner ticks. Step indicator (01 Profile / 02 Program / 03 Submit): active = cyan border+text, done = green.
  - Step 1: Full Name*, Email*, Phone*, City, College*, Degree/Branch (select), Current Year (select).
  - Step 2: Track* (select, 5), Duration (4/8 wk), Mode (4 options), GitHub URL, LinkedIn URL, Statement* (textarea).
  - Step 3: Resume* (dashed drop zone, PDF/DOC/DOCX, max 5MB; label updates to "✓ filename · size KB"), Prior experience (textarea), privacy consent checkbox.
  - Inputs: bg `g-925`, 1px `g-700`, padding 14/16, radius 0; focus → cyan border + `0 0 0 3px rgba(62,230,255,.1)`.
  - Nav: Back (ghost, hidden on step 1) / Continue → (primary; "Submit application →" on step 3).
  - **Success**: hide form, show 80px circle check (cyan, glow), "Application received", reference ID `AX-25-XXXXXX` in dashed box, message about 5-business-day review.

---

## Interactions & Behavior
- **Buttons**: `.2s ease`; arrow `→` translates +4px on hover. Primary hover `#7cf1ff` + stronger glow. Ghost hover → cyan border/text + 6% cyan bg.
- **Pulse**: status dots `opacity 1→.3→1`, 2s ease-in-out infinite.
- **Hero 3D**: drone floats `y = 0.3 + sin(t·0.9)·0.08`, slow yaw +0.003 rad/frame, micro roll/pitch; props spin ±0.9 rad/frame (alternating direction); camera Y follows mouse (lerp .03); 200 cyan points drift. Camera FOV 38 at (3.2, 1.4, 5.5). Fog `#050709` 8→22. Lights: key white 1.2, fill cyan .5, rim amber .35, ambient `#1a2030` .6.
- **Exploder 3D**: drag to orbit (yaw + pitch clamped 0.1–1.3 rad), wheel zoom (radius 3.5–9). Each part group has `origin` + `explodeDir`; position lerps to `origin + dir × explode × 0.55`, where explode eases toward 0/1 at 0.06/frame. Active part materials get cyan emissive (intensity .8); others restored. Reset → collapse + stop rotate + yaw 0.
- **Performance**: DPR capped at 2; render loops pause via IntersectionObserver when off-screen; ResizeObserver for canvas sizing. Production: Draco/KTX2 GLTF, static fallback image for low-WebGL devices.
- **Form**: client validation via Zod (mirror on server). Rate-limit API routes. Store resumes in private S3/R2 with pre-signed URLs.
- **Responsive**: breakpoints at 1100, 1024, 900, 768, 640, 560, 520px as noted.

## State Management
- Landing exploder: `activeHotspotId` (default `camera`), `exploded` (default true), `autoRotate` (false), camera `{angle, pitch, radius}`.
- Internship form: `currentStep` (1–3), form values (react-hook-form + Zod recommended), `submitted`, `referenceId`.
- Data: `POST /api/internships` (multipart, returns reference ID). Prisma models `Applicant`, `WorkshopRegistration`, `Inquiry` per original spec.

## Recommended Implementation Mapping
| Prototype | Production |
|---|---|
| `hero-drone.js` | `components/three/DroneHeroModel.tsx` + `SceneContainer.tsx`, `ParticleField.tsx`, `LightingRig.tsx` (R3F) |
| `exploder.js` | `components/three/InteractiveDroneExploder.tsx` (R3F + Drei `<Html>` hotspots, `OrbitControls` with damping) |
| `build-cards.js` | static data in `lib/content.ts` rendered by `GlassCard` |
| `shared.css` tokens | `tailwind.config.ts` `theme.extend` + `globals.css` utilities |
| form in `internships.html` | `components/forms/InternshipApplyForm.tsx` |

## Assets
- No raster images. Logo = inline SVG (triangle path `M12 2 L22 20 L12 15 L2 20 Z`, cyan stroke 1.5, 8% fill, center dot).
- 3D drone = procedural Three.js primitives (placeholder for `public/models/drone_hero.glb` / `drone_detailed.glb` with named meshes matching hotspot IDs).
- Project visuals = inline SVG placeholders; replace with real field imagery.
- Fonts: Google Fonts (Space Grotesk, Inter, JetBrains Mono). Three.js r161 via CDN import map.

## Files
- `index.html` — landing page markup + page-specific styles
- `internships.html` — internship portal, form logic inline
- `shared.css` — tokens, nav, buttons, badges, glass, ticks, footer
- `hero-drone.js` — hero Three.js scene
- `exploder.js` — interactive exploder scene + hotspot data + detail panel
- `build-cards.js` — capability card data/render
