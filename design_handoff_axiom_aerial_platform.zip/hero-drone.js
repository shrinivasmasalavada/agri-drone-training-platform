import * as THREE from 'three';

// ============ HERO — floating procedural drone ============
const canvas = document.getElementById('hero-canvas');
if (canvas) {
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x050709, 8, 22);

  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
  camera.position.set(3.2, 1.4, 5.5);
  camera.lookAt(0.5, 0.2, 0);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 0);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  // Lighting — 3-point + rim
  const key = new THREE.DirectionalLight(0xffffff, 1.2);
  key.position.set(5, 6, 4);
  key.castShadow = true;
  key.shadow.mapSize.set(1024,1024);
  scene.add(key);

  const fill = new THREE.DirectionalLight(0x3ee6ff, 0.5);
  fill.position.set(-5, 2, 3);
  scene.add(fill);

  const rim = new THREE.DirectionalLight(0xf5a524, 0.35);
  rim.position.set(-2, 4, -5);
  scene.add(rim);

  scene.add(new THREE.AmbientLight(0x1a2030, 0.6));

  // Ground grid (reflective feel via mesh)
  const gridHelper = new THREE.GridHelper(20, 20, 0x252e3d, 0x161c27);
  gridHelper.position.y = -1.2;
  scene.add(gridHelper);

  // ============ DRONE BUILD (procedural) ============
  const drone = new THREE.Group();

  const matDark = new THREE.MeshStandardMaterial({ color:0x1a2030, roughness:0.4, metalness:0.75 });
  const matCarbon = new THREE.MeshStandardMaterial({ color:0x0d1219, roughness:0.6, metalness:0.5 });
  const matAccent = new THREE.MeshStandardMaterial({ color:0x3ee6ff, emissive:0x1aa4bf, emissiveIntensity:0.6, roughness:0.3, metalness:0.6 });
  const matAmber = new THREE.MeshStandardMaterial({ color:0xf5a524, emissive:0xa56e15, emissiveIntensity:0.6 });
  const matBrushed = new THREE.MeshStandardMaterial({ color:0x3a4557, roughness:0.35, metalness:0.9 });

  // Central body (hex prism)
  const bodyGeom = new THREE.CylinderGeometry(0.55, 0.7, 0.28, 6);
  const body = new THREE.Mesh(bodyGeom, matDark);
  body.rotation.y = Math.PI / 6;
  body.castShadow = true;
  drone.add(body);

  // Top plate
  const topPlate = new THREE.Mesh(
    new THREE.CylinderGeometry(0.45, 0.55, 0.06, 6),
    matBrushed
  );
  topPlate.position.y = 0.17;
  topPlate.rotation.y = Math.PI / 6;
  drone.add(topPlate);

  // Accent strip on top
  const accentRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.42, 0.015, 8, 32),
    matAccent
  );
  accentRing.rotation.x = Math.PI / 2;
  accentRing.position.y = 0.22;
  drone.add(accentRing);

  // Camera gimbal (bottom)
  const gimbalArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.12), matBrushed);
  gimbalArm.position.y = -0.24;
  drone.add(gimbalArm);
  const gimbal = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), matDark);
  gimbal.position.y = -0.42;
  drone.add(gimbal);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.06, 32), matCarbon);
  lens.rotation.x = Math.PI / 2;
  lens.position.set(0, -0.42, 0.16);
  drone.add(lens);
  const lensGlow = new THREE.Mesh(new THREE.CircleGeometry(0.07, 32), matAccent);
  lensGlow.position.set(0, -0.42, 0.19);
  drone.add(lensGlow);

  // 4 arms + motors + props
  const armGeom = new THREE.BoxGeometry(1.1, 0.06, 0.08);
  const propellers = [];
  const positions = [
    { x:  1, z:  1, r: -Math.PI/4 },
    { x: -1, z:  1, r:  Math.PI/4 },
    { x: -1, z: -1, r: -Math.PI/4 },
    { x:  1, z: -1, r:  Math.PI/4 },
  ];

  positions.forEach((p, i) => {
    const arm = new THREE.Mesh(armGeom, matCarbon);
    arm.position.set(p.x * 0.45, 0, p.z * 0.45);
    arm.rotation.y = p.r;
    arm.castShadow = true;
    drone.add(arm);

    // motor mount
    const motor = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.14, 0.14, 24),
      matBrushed
    );
    motor.position.set(p.x * 0.85, 0.08, p.z * 0.85);
    motor.castShadow = true;
    drone.add(motor);

    // motor top cap (amber for status)
    const cap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.14, 0.015, 24),
      matAmber
    );
    cap.position.set(p.x * 0.85, 0.16, p.z * 0.85);
    drone.add(cap);

    // propeller (two blades — thin flat)
    const propGroup = new THREE.Group();
    for (let b = 0; b < 2; b++) {
      const blade = new THREE.Mesh(
        new THREE.BoxGeometry(0.6, 0.008, 0.05),
        matDark
      );
      blade.rotation.y = b * Math.PI;
      propGroup.add(blade);
    }
    // hub
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.05, 12), matAccent);
    propGroup.add(hub);
    propGroup.position.set(p.x * 0.85, 0.2, p.z * 0.85);
    drone.add(propGroup);
    propellers.push(propGroup);

    // motion blur disc when spinning (semi-transparent)
    const blur = new THREE.Mesh(
      new THREE.RingGeometry(0.08, 0.32, 32),
      new THREE.MeshBasicMaterial({ color:0x3ee6ff, transparent:true, opacity:0.05, side:THREE.DoubleSide })
    );
    blur.rotation.x = -Math.PI / 2;
    blur.position.set(p.x * 0.85, 0.22, p.z * 0.85);
    drone.add(blur);

    // landing skid stub
    const skid = new THREE.Mesh(
      new THREE.CylinderGeometry(0.02, 0.02, 0.35, 8),
      matCarbon
    );
    skid.position.set(p.x * 0.6, -0.22, p.z * 0.6);
    drone.add(skid);
  });

  // Antenna
  const antenna = new THREE.Mesh(
    new THREE.CylinderGeometry(0.008, 0.008, 0.35, 8),
    matBrushed
  );
  antenna.position.set(0, 0.4, -0.25);
  drone.add(antenna);
  const antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), matAccent);
  antennaTip.position.set(0, 0.58, -0.25);
  drone.add(antennaTip);

  drone.position.y = 0.3;
  drone.scale.setScalar(1.1);
  // shift right for hero composition
  drone.position.x = 0.7;
  scene.add(drone);

  // Particle field (dust)
  const particleCount = 200;
  const particleGeom = new THREE.BufferGeometry();
  const positions_arr = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions_arr[i*3    ] = (Math.random() - 0.5) * 15;
    positions_arr[i*3 + 1] = (Math.random() - 0.5) * 6;
    positions_arr[i*3 + 2] = (Math.random() - 0.5) * 15;
  }
  particleGeom.setAttribute('position', new THREE.BufferAttribute(positions_arr, 3));
  const particleMat = new THREE.PointsMaterial({
    color: 0x3ee6ff, size: 0.02, transparent:true, opacity:0.5, sizeAttenuation:true
  });
  const particles = new THREE.Points(particleGeom, particleMat);
  scene.add(particles);

  // Resize
  function resize() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (w === 0 || h === 0) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(canvas);
  resize();

  // Mouse parallax
  let targetRX = 0, targetRY = 0;
  window.addEventListener('mousemove', (e) => {
    targetRY = (e.clientX / window.innerWidth - 0.5) * 0.3;
    targetRX = (e.clientY / window.innerHeight - 0.5) * 0.15;
  });

  // Animate
  const clock = new THREE.Clock();
  let visible = true;
  const io = new IntersectionObserver(([e]) => visible = e.isIntersecting);
  io.observe(canvas);

  function tick() {
    requestAnimationFrame(tick);
    if (!visible) return;
    const t = clock.getElapsedTime();

    // float
    drone.position.y = 0.3 + Math.sin(t * 0.9) * 0.08;
    drone.rotation.y += 0.003;
    drone.rotation.z = Math.sin(t * 0.7) * 0.02;
    drone.rotation.x = Math.cos(t * 0.5) * 0.015;

    // mouse parallax
    drone.rotation.y += (targetRY - (drone.rotation.y % (Math.PI*2))) * 0.0002;
    camera.position.y += (1.4 + targetRX - camera.position.y) * 0.03;
    camera.lookAt(0.7, 0.2, 0);

    // spin props
    propellers.forEach((p, i) => {
      p.rotation.y += (i % 2 === 0 ? 1 : -1) * 0.9;
    });

    // particles drift
    particles.rotation.y += 0.0004;

    renderer.render(scene, camera);
  }
  tick();
}
