// "What we build" — 6 capability cards
const CARDS = [
  { n:'01', t:'UAV Systems', d:'Custom multirotor & fixed-wing airframes. Aerodynamic simulation, power distribution boards, long-range telemetry links tuned for endurance and payload.', tags:['PX4','Altium','MAVLink','CFD'] },
  { n:'02', t:'Embedded Systems', d:'Ground-up PCB design in KiCad/Altium. STM32H7 & ESP32 firmware, FreeRTOS scheduling, sensor fusion across IMU, LiDAR and time-of-flight arrays.', tags:['STM32','KiCad','FreeRTOS','SPI/I2C'] },
  { n:'03', t:'Edge AI', d:'Quantized neural nets running on Jetson Orin Nano and Pi 5 AI HAT. INT8/FP16 TensorRT engines that deliver 40 TOPS of onboard inference without cloud round-trips.', tags:['TensorRT','ONNX','CUDA','Jetson'] },
  { n:'04', t:'Computer Vision', d:'Optical tracking, YOLOv8 aerial detection, semantic segmentation for inspection workflows, and stereo depth estimation from paired global-shutter sensors.', tags:['YOLOv8','OpenCV','PyTorch','Stereo'] },
  { n:'05', t:'Robotics', d:'Ground and aerial autonomy built on ROS2. SLAM with LOAM/ORB variants, Nav2 stack integration, and reactive path planning through unstructured environments.', tags:['ROS2','SLAM','Nav2','Gazebo'] },
  { n:'06', t:'R&D & Prototyping', d:'Hardware-in-the-loop rigs, wind-tunnel validation, motor thrust benches, and rapid payload integration. Ideas move from whiteboard to flight in weeks, not quarters.', tags:['HIL','SITL','Bench Test','CAD'] },
];

const grid = document.getElementById('build-grid');
if (grid) {
  grid.innerHTML = CARDS.map(c => `
    <article class="build-card">
      <div class="num"><span>// ${c.n} — CAP</span><span class="arrow">↗</span></div>
      <h3 class="title">${c.t}</h3>
      <p class="desc">${c.d}</p>
      <div class="tags">${c.tags.map(t => `<span class="tbadge">${t}</span>`).join('')}</div>
    </article>
  `).join('');
}
