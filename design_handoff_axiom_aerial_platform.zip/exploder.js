import * as THREE from 'three';

// ============ 8 HOTSPOTS metadata ============
const HOTSPOTS = [
  { id:'camera', idx:'01', name:'Camera & Gimbal', spec:'4K Global Shutter', side:'left',
    desc:'A 4K global-shutter optical sensor mounted on a 3-axis brushless gimbal. Global shutter eliminates rolling-shutter distortion during high-speed maneuvers — critical for downstream tracking and photogrammetry pipelines.',
    specs:{'Resolution':'4096 × 2160','Shutter':'Global · 1/8000s','Stabilization':'3-Axis Brushless','Angular Precision':'±0.02°'} },
  { id:'fc', idx:'02', name:'Flight Controller', spec:'STM32H7 Dual-Core', side:'left',
    desc:'Dual-core STM32H7 MCU running our proprietary PID stabilization loop at 8 kHz. Handles motor mixing, sensor fusion, failsafe logic, and MAVLink telemetry to the ground station.',
    specs:{'MCU':'STM32H743 · 480 MHz','Loop Rate':'8 kHz','Firmware':'Custom C++ / FreeRTOS','Failsafes':'RTL · Land · Hold'} },
  { id:'gps', idx:'03', name:'GPS / RTK Module', spec:'±1.4 cm Precision', side:'left',
    desc:'u-blox ZED-F9P dual-band RTK receiver with centimeter-level positioning. Supports GPS, GLONASS, Galileo, and BeiDou for redundancy in obstructed environments.',
    specs:{'Receiver':'u-blox ZED-F9P','Constellations':'4 · Multi-band','Precision':'±1.4 cm CEP','Update Rate':'20 Hz'} },
  { id:'esc', idx:'04', name:'Motor & ESC', spec:'BLHeli32 · Telemetry', side:'left',
    desc:'Brushless DC motors driven by BLHeli32 ESCs with bi-directional DShot600 telemetry. Real-time RPM, current draw, and winding temperature stream back to the flight controller for predictive fault detection.',
    specs:{'Motor':'2207 · 2450 KV','ESC':'BLHeli32 · 60A','Protocol':'DShot600','Feedback':'RPM · I · T°'} },
  { id:'battery', idx:'05', name:'Smart Battery', spec:'6S LiPo · Smart BMS', side:'right',
    desc:'6-cell lithium-polymer intelligent battery pack with an onboard BMS monitoring per-cell voltage, current, and thermal state. Communicates health telemetry via SMBus.',
    specs:{'Chemistry':'6S LiPo · 22.2V','Capacity':'8000 mAh','C-Rating':'25C Cont.','Endurance':'38 min hover'} },
  { id:'link', idx:'06', name:'Comms Link', spec:'OFDM · 12 km', side:'right',
    desc:'Encrypted long-range OFDM transceiver carrying HD video downlink and MAVLink command/telemetry uplink on separate spatial streams. AES-256 encryption end-to-end.',
    specs:{'Modulation':'OFDM · MIMO 2×2','Range':'12 km LOS','Video':'1080p60 · H.265','Encryption':'AES-256-GCM'} },
  { id:'compute', idx:'07', name:'Edge Compute', spec:'Jetson Orin · 40 TOPS', side:'right',
    desc:'NVIDIA Jetson Orin Nano co-processor delivering 40 TOPS of AI inference capacity. Runs quantized YOLOv8-nano at 60fps, semantic segmentation, and stereo depth — entirely onboard, zero cloud dependency.',
    specs:{'SoC':'Jetson Orin Nano','AI Perf.':'40 TOPS · INT8','Memory':'8 GB LPDDR5','Power':'15 W typical'} },
  { id:'sensors', idx:'08', name:'Sensor Suite', spec:'IMU · Baro · TOF · Flow', side:'right',
    desc:'Triple-redundant IMU array voted in software, barometric altitude reference, magnetometer for heading, downward optical flow for GPS-denied hold, and TOF distance sensor for terrain-follow landing.',
    specs:{'IMU':'3× Bosch BMI088','Baro':'DPS310 · ±5 cm','Mag':'RM3100','TOF':'TF-Luna · 8 m'} },
];

// ============ SIDE LISTS ============
function renderLists() {
  const leftHost = document.getElementById('hot-list-left');
  if (!leftHost) return;
  const left = HOTSPOTS.filter(h => h.side === 'left');
  const right = HOTSPOTS.filter(h => h.side === 'right');

  leftHost.innerHTML = left.map(h => hotItem(h)).join('');

  // right side goes in the .exp-detail... but we want a list on the right too.
  // Actually the spec: left column = list of items. Right column = detail panel.
  // So we'll put ALL 8 items in the left column instead. Let me consolidate.
  leftHost.innerHTML = HOTSPOTS.map(h => hotItem(h)).join('');

  document.querySelectorAll('.hot-item').forEach(el => {
    el.addEventListener('click', () => activate(el.dataset.id));
    el.addEventListener('mouseenter', () => activate(el.dataset.id));
  });
}
function hotItem(h) {
  return `<div class="hot-item" data-id="${h.id}">
    <span class="idx">// ${h.idx} / 08</span>
    <div class="name">${h.name}</div>
    <div class="spec">${h.spec}</div>
  </div>`;
}

// ============ DETAIL PANEL ============
function renderDetail(id) {
  const h = HOTSPOTS.find(x => x.id === id) || HOTSPOTS[0];
  const host = document.getElementById('exp-detail');
  if (!host) return;
  host.innerHTML = `
    <span class="eyebrow">§ AX-1 · Component ${h.idx}</span>
    <h3 class="title">${h.name}</h3>
    <p class="desc">${h.desc}</p>
    <div class="specs">
      ${Object.entries(h.specs).map(([k,v]) => `
        <div class="spec-row"><span class="k">${k}</span><span class="v">${v}</span></div>
      `).join('')}
    </div>
    <div style="margin-top:32px;padding-top:20px;border-top:1px dashed var(--g-700)">
      <div style="font-family:var(--f-mono);font-size:10px;letter-spacing:.2em;color:var(--g-500);text-transform:uppercase;margin-bottom:10px">// Status</div>
      <div style="display:flex;align-items:center;gap:10px;font-family:var(--f-mono);font-size:11px;letter-spacing:.14em;color:var(--green);text-transform:uppercase">
        <span class="dot live pulse"></span>NOMINAL · FIELD-VALIDATED
      </div>
    </div>
  `;
  document.getElementById('exp-active').textContent = `[ ${h.name.toUpperCase()} ]`;
  document.querySelectorAll('.hot-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === id);
  });

  // 3D highlight
  highlightPart(id);
}

let activeId = HOTSPOTS[0].id;
function activate(id) {
  activeId = id;
  renderDetail(id);
}

renderLists();

// ============ THREE.JS EXPLODER SCENE ============
const canvas = document.getElementById('exp-canvas');
if (!canvas) { throw new Error('no exp canvas'); }

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x0b0f16, 10, 25);

const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
camera.position.set(3.5, 2.2, 4.5);

const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setClearColor(0x000000, 0);

const key = new THREE.DirectionalLight(0xffffff, 1.0);
key.position.set(5, 8, 4);
scene.add(key);

const fill = new THREE.DirectionalLight(0x3ee6ff, 0.6);
fill.position.set(-6, 3, 2);
scene.add(fill);

const rim = new THREE.DirectionalLight(0xf5a524, 0.3);
rim.position.set(0, 3, -6);
scene.add(rim);

scene.add(new THREE.AmbientLight(0x1a2030, 0.7));

// grid disc under drone
const disc = new THREE.Mesh(
  new THREE.RingGeometry(1.5, 3.5, 64, 1),
  new THREE.MeshBasicMaterial({ color:0x3ee6ff, transparent:true, opacity:0.08, side:THREE.DoubleSide })
);
disc.rotation.x = -Math.PI / 2;
disc.position.y = -1;
scene.add(disc);

const disc2 = new THREE.Mesh(
  new THREE.RingGeometry(1.5, 1.52, 64, 1),
  new THREE.MeshBasicMaterial({ color:0x3ee6ff, transparent:true, opacity:0.4, side:THREE.DoubleSide })
);
disc2.rotation.x = -Math.PI / 2;
disc2.position.y = -0.99;
scene.add(disc2);

// ============ BUILD DRONE WITH LABELED PARTS ============
const droneRoot = new THREE.Group();
const parts = {}; // id -> { group, origin (Vector3), explodeDir (Vector3), meshes[] }

const matDark = new THREE.MeshStandardMaterial({ color:0x1a2030, roughness:0.4, metalness:0.75 });
const matCarbon = new THREE.MeshStandardMaterial({ color:0x0d1219, roughness:0.6, metalness:0.5 });
const matAccent = new THREE.MeshStandardMaterial({ color:0x3ee6ff, emissive:0x1aa4bf, emissiveIntensity:0.6, roughness:0.3, metalness:0.6 });
const matAmber = new THREE.MeshStandardMaterial({ color:0xf5a524, emissive:0xa56e15, emissiveIntensity:0.6 });
const matBrushed = new THREE.MeshStandardMaterial({ color:0x3a4557, roughness:0.35, metalness:0.9 });
const matGreen = new THREE.MeshStandardMaterial({ color:0x0f3324, emissive:0x0a1f14, roughness:0.6 });

function addPart(id, origin, explodeDir) {
  const g = new THREE.Group();
  g.userData.id = id;
  g.userData.origin = origin.clone();
  g.userData.explodeDir = explodeDir.clone();
  g.position.copy(origin);
  droneRoot.add(g);
  parts[id] = { group:g, meshes:[] };
  return g;
}
function mark(part, mesh) {
  parts[part].meshes.push(mesh);
  part.add?.(mesh) ?? part.group.add(mesh);
  return mesh;
}

// ---- BODY (not a hotspot but visual center) ----
const bodyGroup = new THREE.Group();
droneRoot.add(bodyGroup);

const body = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 0.28, 6), matDark);
body.rotation.y = Math.PI / 6;
bodyGroup.add(body);
const topPlate = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.06, 6), matBrushed);
topPlate.position.y = 0.17;
topPlate.rotation.y = Math.PI / 6;
bodyGroup.add(topPlate);

// ---- 01 CAMERA / GIMBAL ---- (goes down)
const gCam = addPart('camera', new THREE.Vector3(0, -0.35, 0), new THREE.Vector3(0, -1, 0));
const gimbalArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.12), matBrushed);
gimbalArm.position.y = 0.05;
gCam.add(gimbalArm);
parts['camera'].meshes.push(gimbalArm);
const gimbal = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), matDark);
gimbal.position.y = -0.12;
gCam.add(gimbal); parts['camera'].meshes.push(gimbal);
const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.06, 32), matCarbon);
lens.rotation.x = Math.PI / 2;
lens.position.set(0, -0.12, 0.16);
gCam.add(lens); parts['camera'].meshes.push(lens);
const lensGlow = new THREE.Mesh(new THREE.CircleGeometry(0.07, 32), matAccent);
lensGlow.position.set(0, -0.12, 0.19);
gCam.add(lensGlow); parts['camera'].meshes.push(lensGlow);

// ---- 02 FLIGHT CONTROLLER ---- (top, goes up)
const gFc = addPart('fc', new THREE.Vector3(0, 0.28, 0), new THREE.Vector3(0, 1, 0));
const fcPcb = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.03, 0.55), matGreen);
gFc.add(fcPcb); parts['fc'].meshes.push(fcPcb);
const fcChip = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.04, 0.16), matDark);
fcChip.position.y = 0.035;
gFc.add(fcChip); parts['fc'].meshes.push(fcChip);
// tiny LEDs
for (let i = 0; i < 3; i++) {
  const led = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.01, 8), matAccent);
  led.position.set(-0.2 + i*0.05, 0.03, 0.22);
  gFc.add(led); parts['fc'].meshes.push(led);
}

// ---- 03 GPS ---- (top-back, up-back)
const gGps = addPart('gps', new THREE.Vector3(0, 0.5, -0.35), new THREE.Vector3(0, 0.6, -1));
const gpsDome = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.08, 16), matCarbon);
gGps.add(gpsDome); parts['gps'].meshes.push(gpsDome);
const gpsTop = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 8, 0, Math.PI*2, 0, Math.PI/2), matBrushed);
gpsTop.position.y = 0.04;
gGps.add(gpsTop); parts['gps'].meshes.push(gpsTop);

// ---- 04 ESC/MOTORS (all 4 arms) ---- (radial explosion)
const armPositions = [
  { x:  1, z:  1 }, { x: -1, z:  1 }, { x: -1, z: -1 }, { x:  1, z: -1 },
];
// We treat all 4 motor assemblies as one 'esc' hotspot group visually,
// but each motor stays attached to its arm. Explode = arms & motors move outward.
armPositions.forEach((p, i) => {
  const dir = new THREE.Vector3(p.x, 0.1, p.z).normalize();
  const g = addPart(`esc_${i}`, new THREE.Vector3(p.x * 0.75, 0.05, p.z * 0.75), dir);
  // arm
  const armLen = 0.9;
  const arm = new THREE.Mesh(new THREE.BoxGeometry(armLen, 0.06, 0.08), matCarbon);
  arm.position.set(-p.x * armLen * 0.45, -0.05, -p.z * armLen * 0.45);
  arm.rotation.y = Math.atan2(p.z, p.x);
  // simpler: align arm along X
  arm.rotation.y = 0;
  // position/rotation is fussy; do it via a helper
  g.remove(arm);
  const armGroup = new THREE.Group();
  const armMesh = new THREE.Mesh(new THREE.BoxGeometry(armLen, 0.06, 0.08), matCarbon);
  armMesh.position.set(-armLen/2, -0.05, 0);
  armGroup.add(armMesh);
  armGroup.rotation.y = Math.atan2(-p.z, -p.x);
  g.add(armGroup);
  parts[`esc_${i}`].meshes.push(armMesh);

  // motor
  const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.14, 24), matBrushed);
  motor.position.y = 0.03;
  g.add(motor); parts[`esc_${i}`].meshes.push(motor);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.015, 24), matAmber);
  cap.position.y = 0.11;
  g.add(cap); parts[`esc_${i}`].meshes.push(cap);
  // prop
  const propG = new THREE.Group();
  for (let b = 0; b < 2; b++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.008, 0.05), matDark);
    blade.rotation.y = b * Math.PI;
    propG.add(blade);
    parts[`esc_${i}`].meshes.push(blade);
  }
  propG.position.y = 0.15;
  g.add(propG);
  g.userData.prop = propG;
});

// ---- 05 BATTERY ---- (bottom, goes down further & forward)
const gBatt = addPart('battery', new THREE.Vector3(0, -0.1, 0), new THREE.Vector3(0, -0.7, 0.7));
const batt = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.16, 0.35), matDark);
gBatt.add(batt); parts['battery'].meshes.push(batt);
const battLabel = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.02, 0.2), matAmber);
battLabel.position.y = 0.09;
gBatt.add(battLabel); parts['battery'].meshes.push(battLabel);
// pull it down so it sits below body but above camera; adjust
gBatt.position.y = -0.05;
gBatt.userData.origin.set(0, -0.05, 0);

// ---- 06 COMMS LINK ---- (back, goes back)
const gLink = addPart('link', new THREE.Vector3(0, 0.15, -0.4), new THREE.Vector3(0, 0.3, -1));
const linkBody = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.15), matDark);
gLink.add(linkBody); parts['link'].meshes.push(linkBody);
// two antennas
for (let a = 0; a < 2; a++) {
  const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.28, 8), matBrushed);
  ant.position.set(-0.08 + a*0.16, 0.2, 0);
  gLink.add(ant); parts['link'].meshes.push(ant);
  const antTip = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 8), matAccent);
  antTip.position.set(-0.08 + a*0.16, 0.35, 0);
  gLink.add(antTip); parts['link'].meshes.push(antTip);
}

// ---- 07 EDGE COMPUTE (Jetson) ---- (top-front, up-forward)
const gCompute = addPart('compute', new THREE.Vector3(0, 0.42, 0.3), new THREE.Vector3(0, 0.6, 1));
const jetson = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.05, 0.35), matGreen);
gCompute.add(jetson); parts['compute'].meshes.push(jetson);
// heatsink fins
for (let f = 0; f < 6; f++) {
  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.08, 0.02), matBrushed);
  fin.position.set(0, 0.06, -0.15 + f*0.06);
  gCompute.add(fin); parts['compute'].meshes.push(fin);
}
// glow strip
const glow = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.005, 0.02), matAccent);
glow.position.set(0, 0.11, 0.16);
gCompute.add(glow); parts['compute'].meshes.push(glow);

// ---- 08 SENSOR SUITE ---- (side, goes right)
const gSens = addPart('sensors', new THREE.Vector3(0.4, 0.05, 0.2), new THREE.Vector3(1, 0.3, 0.5));
const sensPcb = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.02, 0.14), matGreen);
gSens.add(sensPcb); parts['sensors'].meshes.push(sensPcb);
const sensChip1 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.05), matDark);
sensChip1.position.set(-0.04, 0.02, 0);
gSens.add(sensChip1); parts['sensors'].meshes.push(sensChip1);
const sensChip2 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.05), matDark);
sensChip2.position.set(0.04, 0.02, 0);
gSens.add(sensChip2); parts['sensors'].meshes.push(sensChip2);
const sensLed = new THREE.Mesh(new THREE.SphereGeometry(0.01, 8, 8), matAmber);
sensLed.position.set(0, 0.03, 0.05);
gSens.add(sensLed); parts['sensors'].meshes.push(sensLed);

scene.add(droneRoot);

// Consolidate esc_0..3 into 'esc' meshes list for highlight
parts['esc'] = { meshes: [] };
[0,1,2,3].forEach(i => {
  parts['esc'].meshes.push(...parts[`esc_${i}`].meshes);
});

// ============ INTERACTION ============
let exploded = true; // start exploded per spec's spirit
let autoRotate = false;
let hoverLerp = 0;

const btnExplode = document.getElementById('btn-explode');
const btnRotate = document.getElementById('btn-rotate');
const btnReset = document.getElementById('btn-reset');

btnExplode.addEventListener('click', () => {
  exploded = !exploded;
  btnExplode.classList.toggle('on', exploded);
});
btnRotate.addEventListener('click', () => {
  autoRotate = !autoRotate;
  btnRotate.classList.toggle('on', autoRotate);
});
btnReset.addEventListener('click', () => {
  exploded = false; autoRotate = false;
  btnExplode.classList.toggle('on', false);
  btnRotate.classList.toggle('on', false);
  droneRoot.rotation.y = 0;
});

// Highlight — dim non-active parts, brighten active
function highlightPart(id) {
  const allIds = ['camera','fc','gps','esc','battery','link','compute','sensors'];
  allIds.forEach(pid => {
    const p = parts[pid];
    if (!p || !p.meshes) return;
    const active = pid === id;
    p.meshes.forEach(m => {
      if (!m.material) return;
      if (!m.userData.origEmiss && m.material.emissive) {
        m.userData.origEmiss = m.material.emissive.clone();
        m.userData.origEmissI = m.material.emissiveIntensity ?? 0;
      }
      if (m.material.emissive) {
        if (active) {
          m.material.emissive.setHex(0x3ee6ff);
          m.material.emissiveIntensity = 0.8;
        } else if (m.userData.origEmiss) {
          m.material.emissive.copy(m.userData.origEmiss);
          m.material.emissiveIntensity = m.userData.origEmissI;
        }
      }
    });
  });
}

// Ambient orbit interaction (drag to rotate)
let dragging = false, prevX = 0, prevY = 0, camAng = 0, camPitch = 0.5;
let camRadius = 5.8;
canvas.addEventListener('pointerdown', (e) => {
  dragging = true; prevX = e.clientX; prevY = e.clientY;
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointerup', () => dragging = false);
canvas.addEventListener('pointermove', (e) => {
  if (!dragging) return;
  const dx = e.clientX - prevX; const dy = e.clientY - prevY;
  camAng -= dx * 0.008;
  camPitch = Math.max(0.1, Math.min(1.3, camPitch + dy * 0.005));
  prevX = e.clientX; prevY = e.clientY;
});
canvas.addEventListener('wheel', (e) => {
  e.preventDefault();
  camRadius = Math.max(3.5, Math.min(9, camRadius + e.deltaY * 0.003));
}, { passive:false });

// Resize
function resize() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (!w || !h) return;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
const ro = new ResizeObserver(resize);
ro.observe(canvas);
resize();

// Initial state
renderDetail(activeId);

// Animate
const clock = new THREE.Clock();
let visible = true;
const io = new IntersectionObserver(([e]) => visible = e.isIntersecting);
io.observe(canvas);

function tick() {
  requestAnimationFrame(tick);
  if (!visible) return;
  const t = clock.getElapsedTime();

  // camera orbit
  if (autoRotate) camAng += 0.005;
  camera.position.x = Math.sin(camAng) * camRadius * Math.cos(camPitch);
  camera.position.z = Math.cos(camAng) * camRadius * Math.cos(camPitch);
  camera.position.y = Math.sin(camPitch) * camRadius;
  camera.lookAt(0, 0, 0);

  // explode lerp
  hoverLerp += ((exploded ? 1 : 0) - hoverLerp) * 0.06;

  // move parts
  Object.entries(parts).forEach(([id, p]) => {
    if (!p.group) return;
    const target = p.group.userData.origin.clone().add(
      p.group.userData.explodeDir.clone().multiplyScalar(hoverLerp * 0.55)
    );
    p.group.position.lerp(target, 0.15);
    if (p.group.userData.prop) p.group.userData.prop.rotation.y += 0.08 * (1 - hoverLerp);
  });

  // subtle float
  droneRoot.position.y = Math.sin(t * 0.8) * 0.04;

  renderer.render(scene, camera);
}
tick();
